---
name: "viral-reel-remix"
description: "Edits raw talking-head video into a stylish Instagram Reel: cuts silences, adds styled subtitles, text behind the head, zoom-ins, stickers, music and SFX."
---

# Viral Reel Remix

Two modes, same engine (`reference/engine.md`, scripts in `scripts/`, helper tool at the end of this file):
- **A. Reference reel given:** keep its *structure and editing style*, rebuild it around the user's recording.
- **B. Only their own footage** ("make a reel from this", "same as last time"): use the **house style** in section 2B.

What the user cares about in every edit, whichever mode: **the footage looks exactly as the user shot it** (no colour grade, no vignette, no glow filters), **no dead air**, **stylish readable text**, and **a high-quality file**.

## 0. Talk to the user first
One line on what you'll do. Mode A needs (1) the reference reel as a video file (a phone screen-recording is fine) and (2) their recording. If they only have the reference, offer to write the script first: keep the structure, write new words in the user's language and voice, never the reference's script word for word. Mode B needs nothing more: start.
Ask once, alongside the first results, whether the user has a copyright-free music track they want (section 6). If they don't answer, use a generated bed.
Tell them once: **"I'll install some free tools in my sandbox. If Claude asks for permission, just approve."**
If they say "don't spend much time", plan for one test sheet + one fix pass and at most 2 text-behind-head moments.

## 1. Fast start (run in parallel)
```bash
S=<this skill folder>/scripts; mkdir -p ~/edit/tools ~/edit/look
nohup bash $S/setup.sh <lang> > ~/edit/setup.log 2>&1 &      # ~3 min; non-en downloads the 1B omnilingual model
ffmpeg -v error -i <upload> -vf "fps=1/2,scale=180:-1,tile=12x6" -frames:v 1 ~/edit/look/raw_sheet.jpg
```
- `prep.py` needs `env.json` (written at the end of setup). If setup is still running, run prep's ffmpeg lines yourself, and extract 16 kHz audio straight from the upload and start `transcribe.py` on it while `src.mp4` encodes (same timings).
- **Resolution:** check the upload's size. If it is 4K (2160 wide) and you plan zoom-ins above 1.2, run `prep.py <video> --max 2160` so the push-in stays sharp (composite gets slower, ~1.8×). Otherwise the default 1440 is fine.
- Typical times on 2 CPUs for a 1-min edit: transcribe 3 min, masks ~0.6 s per frame, overlay render ~0.22 s/frame per shard, composite ~200 frames/min, finish 1–4 min. Start long steps with `nohup … &` and poll with `sleep ≤115` (tool calls time out at 2 min). With two logs use `for f in a.log b.log; do tail -n 1 $f; done`.

## 2. Study the reference (Mode A)
```bash
ffmpeg -i ref.mp4 -vf "fps=2,scale=180:-1,tile=10x6" -frames:v 1 ~/edit/ref_sheet.jpg      # 2 frames per second
ffmpeg -i ref.mp4 -vf "select='gt(scene,0.25)',showinfo" -an -f null - 2>&1 | grep -o "pts_time:[0-9.]*"   # cut points
```
Look at the sheets (make more around interesting moments) and write `~/edit/style.md`:
- **Timeline of beats:** time → layout (face full / split screen / colour card / screen recording) → what's shown → what's said.
- **Palette:** the 3–5 colours of the cards (sample with Python from frames), text colours, accent.
- **Captions:** position, box or no box, size, word highlight colour, case.
- **Type:** headline style, text behind the person, stickers, counters. Map the reference's fonts to the closest ones in section 5's font set.
- **Pace:** average shot length, zoom-ins, how often the layout changes.
- **Sound:** where the whooshes/pops land; whether music is there (yes → use a bed of similar mood, section 6).
- **Hook:** what's on screen at frame 0.

## 2B. House style (Mode B)
What this user wants: clean and stylish, not flashy. The footage stays natural; the style comes from **typography**, **text behind the head**, and **smooth zoom-ins**. Viewers must know the topic in the first second.
- **Hook (frame 0 = IG cover):** the topic in 1–2 big words *behind the head* (`BACKTEXT`, Anton for English, Baloo Chettan for Malayalam, size 240–330, cream `#F7F2EA` or the accent), already fully drawn at t=0, plus the stacked caption of the first line. No title box, no top headline bar.
- **Text behind the head on key points:** 3–5 moments per reel, each 1.5–3 s, on the word that names the idea (the topic, the big number, the payoff, "free", "2x"). Alternate cream and accent colour; one may use the condensed `var(--fcond)` (Bebas) for variety. Masks cost ~0.6 s per frame, so keep the total under ~15 s of masked time. Place the word so the head covers its lower third (top ≈ head-top − 0.6 × size); check every one in the test sheet: the face must never be covered and the word must still read.
- **Smooth zoom-in on key points** (always on a wide or medium shot: the face is less than ~1/4 of the frame height, or there's lots of room around the person): `plan.json` `"focus"` push-in to 1.25–1.4 over ~0.45 s *as the main point starts*, hold while it's said, ease back out. 3–6 per minute; never two back to back; not during a text-behind-head moment unless you re-check the word still fits. On a close-up shot use gentler 1.08–1.12 pushes instead. Base `zoom` stays 1.0 (no constant creep). Set `fx/fy` in the focus entry to the face so the push centres on it.
- **Footage untouched:** `"grade":0` and `"pop":1.0` in `plan.json` (these are now the defaults). No vignette, no glow over the video, no colour cards over the face unless a reference asks for them. The bottom shade under captions is light on purpose; leave it.
- **Captions:** stacked `st` at y≈1290 on the full face (small words + one big key word in the accent), Montserrat for English, Baloo Chettan 2 for Malayalam (automatic through `--fcap`). 1–4 words per line, 3–7 accent words per reel. Optionally `~` serif (Playfair italic) on one or two English emphasis words.
- **Small text elements, sparingly:** a handwritten sticker (`.sticker`, Permanent Marker / Chilanka) for an aside like "2x ROAS" or "free", or a counter rolling up to a number. At most one on screen at a time, never covering the face.
- **Split-screen explainers: optional.** Use one only when the user explains something visual (a from→to flow, a short list) and the face can sit in the top card; otherwise stay full-face with zooms. Recipes: `reference/engine.md`.
- **Not part of this style any more** (don't add unless the user asks): white title box, cropped UI card with cursor, step pills, yellow highlight rings, checklist ending, Follow/Share CTA row, colour grade, subject-pop darkening.
- **Palette:** accent chosen for contrast with the user's clothes (yellow `#FFC83D` on red/dark shirts, orange `#FF6A2B` on blue/grey); cream `#F7F2EA` for back text; white captions.
- **Sound:** quiet SFX (`air` on a zoom-in −32, `pop` on a sticker −32, one `hit` −26 for the biggest moment) + a low music bed (section 6).

## 3. Prepare, cut silences, transcribe
`prep.py` → `transcribe.py` (or ElevenLabs if connected) → `autocut.py` (silences) → edit `keep.json` for retention cuts → `cuts.py apply` → re-transcribe `voice_cut16.wav` → `subs.txt`/`subs.py`.
- **Every blank gap goes.** `python3 $S/autocut.py` removes every silence ≥ 0.30 s and leaves ~0.18 s at each join, so speech flows with no dead air; short breaths stay so it doesn't sound robotic. It prints each cut. Noisy room (cuts missed) → `--thr -24`; voice getting clipped at word ends → `--pad 0.12`.
- **Then cut for retention** (expect another −10–15 %) with `--drop` using word times: "if you already know this, skip the video", backstory ("I saw someone doing this…"), the same instruction said twice, stumbles/false starts. Example: `python3 $S/autocut.py --drop 12.4 15.9 31.0 33.2`. Keep the explanation of any error shown on screen.
- Malayalam/Indic geminates (പ്പ ക്ക ട്ട ത്ത) make a silence *inside* the word; autocut ignores holes under 60 ms, and `--drop` boundaries should sit in pauses (`reeltools.py quiet`) or at dips ≤ −20 dB (`reeltools.py dips`), never mid-word. Cross-check with word times (`reeltools.py words chars.json`).
- Need a different layout before and after a point in continuous speech? Split the keep segment inside a pause; every segment boundary gets short fades. `plan.json` needs one zoom pair per segment.
- After `cuts.py apply`, re-transcribe and **read every join**: no clipped word, no double breath. Write down each segment's offset (out = src − src0 + out0) for overlay timings.

## 4. Map words onto the structure
Mode A: match each reference beat to the sentence that plays the same role (hook, claim, list, proof, steps, CTA); keep its layout order and rhythm. Mode B: pick the 3–5 key words for text-behind-head (the first one is the hook), the 3–6 main points for zoom-ins, and the 3–7 caption accent words. Write them as a short list before building.

## 5. Build
- `overlay.html` from `templates/overlay.html`. Mode A: `--acc` and card colours from the reference palette; captions `pill` if the reference boxes them, else `st`/`in`. Hook on frame 0 exactly like the reference.
- **Fonts** (installed by `setup.sh`, set as CSS variables in the template; each English font is paired with a Malayalam one so mixed lines look consistent):

  | Variable | English | Malayalam | Use for |
  |---|---|---|---|
  | `--fcap` | Montserrat 700–900 | Baloo Chettan 2 | captions, pills, small text (default) |
  | `--fdisp` | Anton | Baloo Chettan 2 | text behind the head, hook, big statements |
  | `--fcond` | Bebas Neue | Baloo Chettan 2 | tall condensed back text, numbers |
  | `--fserif` | Playfair Display italic | Baloo Chettan 2 | one or two elegant emphasis words |
  | `--fhand` | Permanent Marker | Chilanka | stickers, handwritten asides |

  Don't mix more than three of these in one reel. Anton/Bebas have no Malayalam letters, so Malayalam back text falls to Baloo Chettan automatically; use size 200–260 for it (wider glyphs). Hindi/Tamil/Arabic fall back to Noto via `LOC`.
- `BACKTEXT` entries: `{t0, t1, text, top, size, color, glowAt, family, font, ls}` + the same ranges in `overlay_cfg.json` `{"back":[[t0,t1],...]}` + `python3 $S/masks.py t0 t1 …` for those ranges (needs the cut-out model from setup).
- `plan.json` for the house style:
  ```json
  {"anchors":[{"until":999,"fx":0.5,"fy":0.32}],"zoom":[[1,1],[1,1]],
   "focus":[[4.8,7.6,1.35,0.45,0.5,0.28]],"grade":0,"pop":1.0}
  ```
  `focus` = `[t_in, t_out, zoom, ramp_seconds, face_x, face_y]` in output time.
- Replace any mascot, cartoon character, person illustration or brand logo with cards, shapes, stickers, counters and simple UI mock-ups. Brand names as plain text are fine. Mock-up numbers must be labelled as examples or be the user's real numbers.
- **Captions:** the omnilingual model gives merged/garbled Malayalam and English words in Malayalam script. Rewrite every line: Malayalam script, English terms in Latin (`campaign-ൽ`, `ad set`, `duplicate`, `Ads Manager`), normal spelling. When the ASR merges two words, take the second word's time from the raw transcript + segment offset. Never let a chunk straddle a layout/`capStyle` change.
- No emoji (headless Chromium has no colour emoji font): use inline SVG icons or plain symbols like ✓.
- **Test:** ~30 frames covering every hook, back-text moment, zoom peak and sticker (`render_overlay.py ovt f1,f2,…`, then `composite.py test ovt f1,… sheet.jpg look/full`), and also look at 2–4 full frames at 540 px wide: the small sheet hides covered faces, cut-off words and soft zooms. Fix, then full render → composite.

## 6. Sound, finish, deliver
- **Music (quiet, copyright-safe).** Only two sources, so nothing gets muted or claimed on Instagram/Meta:
  1. a track the user gives you from a copyright-free library (YouTube Audio Library, Pixabay Music, Meta Sound Collection) or one they have a licence for: `python3 $S/music.py file track.mp3 [--start 12]`;
  2. otherwise an original bed made in code (no samples, nothing to claim): `python3 $S/music.py gen calm|lofi|upbeat`. calm = soft keys and pad for explainers, lofi = gentle beat, upbeat = brighter beat for fast tips.
  Never pull a song from the web or match a popular track. `finish.py` mixes it 16 dB under the voice and ducks it further while the user talks (`--music-db -13` louder, `-20` barely there, `--no-music` off).
- `sfx.py` (quiet, see 2B), then `python3 $S/finish.py <name>`. It mixes to −14 LUFS and writes the **high-quality reel** `<name>.mp4`: the composite's CRF 15 video untouched when it fits under 100 MB, else CRF 17 slow, else a 2-pass held to 100 MB (`--max-mb` to change). Check `final_sheet.jpg` (Mode A: next to `ref_sheet.jpg`) and `first_frame.jpg` (the cover).
- **Delivering a big file.** The chat attachment limit is about 30 MB, so:
  1. HQ ≤ 30 MB → send `<name>.mp4` with SendUserFile.
  2. HQ > 30 MB and the user's computer is linked → write `<name>.mp4` into the folder they ask for (Downloads by default) through the device tools and say where it is. If that is refused for size, go on.
  3. Otherwise ask once whether to upload it to the user's Descript (if connected) with `import_media` (upload URL + PUT from the sandbox); they can download the full-quality file there.
  4. Last resort: `finish.py` also made `<name>-share.mp4` (≤29 MB, 2-pass). Send that, say it's a lighter copy, and that the full-quality file is ready as soon as they link the desktop app.

## 7. Final message
Short: what you kept (Mode A) or which house-style pieces you used (back-text words, number of zoom-ins); how much dead air and what else you cut and why; words you guessed in the subtitles; on-screen errors or limits viewers may ask about; **anything the video claims that the product doesn't actually do**; the music source (the user's track or the generated bed) and file size/quality.

## Helper: `~/edit/tools/reeltools.py`
```python
"""reeltools.py  quiet|dips|words|seam
  quiet <wav> <t0> <t1> [thr=-22] [min_ms=150]   pauses (dB below the 95th-percentile speech level)
  dips  <wav> <t0> <t1> [thr=-12]                quiet points inside speech = in-speech cut candidates
  words <chars.json> <out.json>                  word start+end from transcribe.py --chars output
  seam  <video> <t> [t ...]                      y of a full-width horizontal edge (screen-rec over face cam)"""
import sys, json, subprocess, numpy as np
def curve(wav):
    import soundfile as sf
    a, sr = sf.read(wav); h = sr // 200
    if a.ndim > 1: a = a.mean(1)
    d = 20*np.log10(np.array([np.sqrt(np.mean(a[i:i+2*h]**2)) for i in range(0, len(a)-2*h, h)])+1e-9)
    return d - np.percentile(d, 95)          # 5 ms steps, 0 = speech level
c, v = sys.argv[1], sys.argv[2:]
if c == 'quiet':
    d = curve(v[0]); t0, t1 = float(v[1]), float(v[2]); thr = float(v[3]) if len(v) > 3 else -22; mn = float(v[4]) if len(v) > 4 else 150
    i = int(t0*200)
    while i < min(len(d), int(t1*200)):
        if d[i] < thr:
            j = i
            while j < len(d) and d[j] < thr: j += 1
            if (j-i)*5 >= mn: print(f"{i/200:7.2f}-{j/200:7.2f}  {(j-i)*5:4d} ms")
            i = j
        else: i += 1
elif c == 'dips':
    d = curve(v[0]); t0, t1 = float(v[1]), float(v[2]); thr = float(v[3]) if len(v) > 3 else -12
    s = d[int(t0*200):int(t1*200)]
    print(' '.join(f"{t0+k/200:.3f}({s[k]:.0f})" for k in range(len(s)) if s[k] == s[max(0,k-6):k+7].min() and s[k] < thr))
elif c == 'words':
    W, cur, last = [], None, 0
    for tok, t in json.load(open(v[0])):
        if tok.strip() == '':
            if cur: cur['e'] = round(max(t, last+0.04), 2); W.append(cur); cur = None
            continue
        cur = cur or {'w': '', 's': t}; cur['w'] += tok; last = t
    if cur: cur['e'] = round(last+0.08, 2); W.append(cur)
    json.dump(W, open(v[1], 'w'), ensure_ascii=False)
    print('  '.join(f"{i}:{w['w']}@{w['s']}-{w['e']}" for i, w in enumerate(W)))
elif c == 'seam':
    for t in v[1:]:
        raw = subprocess.run(['ffmpeg','-v','error','-ss',t,'-i',v[0],'-frames:v','1','-vf','scale=1080:1920','-f','rawvideo','-pix_fmt','gray','-'], capture_output=True).stdout
        g = np.frombuffer(raw, np.uint8).reshape(1920, 1080).astype(float); f = (np.abs(g[1:]-g[:-1]) > 18).mean(1)
        r = int(np.argmax(f[300:1600]))+300; print(t, r if f[r] > 0.6 else 'none', round(float(f[r]), 2))
```

