"""Cut every blank/silent gap automatically -> keep.json (then run cuts.py apply).
usage: python3 autocut.py [--thr -30] [--gap 0.30] [--pad 0.09] [--range t0 t1] [--drop t0 t1 ...]
  --thr   dB below the speech level (95th percentile) that counts as silence (default -30; noisy room: -24)
  --gap   silences at least this long are removed (default 0.30 s). Shorter ones are breathing room, keep them.
  --pad   speech kept on each side of a removed silence (default 0.09 s -> ~0.18 s pause left at a join)
  --range only use this part of the source (e.g. skip a clap at the start)
  --drop  extra source ranges to remove (retakes, "skip if you know this", repeated lines). Use word times from words.json.
reads ~/edit/audio16k.wav (source time), writes ~/edit/keep.json and prints every removed gap."""
import sys, os, json, numpy as np, soundfile as sf
os.chdir(os.path.expanduser('~/edit'))
a = sys.argv[1:]
def opt(k, d):
    return float(a[a.index(k) + 1]) if k in a else d
thr, gap, pad = opt('--thr', -30), opt('--gap', 0.30), opt('--pad', 0.09)
x, sr = sf.read('audio16k.wav')
if x.ndim > 1: x = x.mean(1)
hop = sr // 100                                   # 10 ms
db = 20 * np.log10(np.array([np.sqrt(np.mean(x[i:i + 2 * hop] ** 2)) for i in range(0, len(x) - 2 * hop, hop)]) + 1e-9)
db -= np.percentile(db, 95)
loud = db > thr
# close tiny holes (<60 ms: consonant closures, Malayalam geminates) so they never count as silence
k = 0
while k < len(loud):
    if not loud[k]:
        j = k
        while j < len(loud) and not loud[j]: j += 1
        if (j - k) < 6 and k > 0: loud[k:j] = True
        k = j
    else: k += 1
# speech islands
isl = []; k = 0
while k < len(loud):
    if loud[k]:
        j = k
        while j < len(loud) and loud[j]: j += 1
        if j - k >= 4: isl.append([k / 100, j / 100])    # ignore clicks shorter than 40 ms
        k = j
    else: k += 1
if not isl: sys.exit('no speech found: lower --thr')
dur = len(x) / sr
r0, r1 = (opt('--range', 0), float(a[a.index('--range') + 2])) if '--range' in a else (0, dur)
isl = [[max(s, r0), min(e, r1)] for s, e in isl if e > r0 and s < r1]
# merge islands separated by less than --gap, pad the rest
keep = []
for s, e in isl:
    if keep and s - keep[-1][1] < gap: keep[-1][1] = e
    else: keep.append([s, e])
keep = [[max(0, s - pad), min(dur, e + pad)] for s, e in keep]
merged = []
for s, e in keep:
    if merged and s <= merged[-1][1] + 0.02: merged[-1][1] = max(merged[-1][1], e)
    else: merged.append([s, e])
# manual drops
if '--drop' in a:
    v = []
    for t in a[a.index('--drop') + 1:]:
        if t.startswith('--'): break
        v.append(float(t))
    for d0, d1 in zip(v[::2], v[1::2]):
        out = []
        for s, e in merged:
            if e <= d0 or s >= d1: out.append([s, e])
            else:
                if s < d0 and d0 - s > 0.15: out.append([s, d0])
                if e > d1 and e - d1 > 0.15: out.append([d1, e])
        merged = out
merged = [[round(s, 3), round(e, 3)] for s, e in merged if e - s > 0.12]
json.dump(merged, open('keep.json', 'w'))
total = sum(e - s for s, e in merged)
print(f'source {dur:.2f}s -> kept {total:.2f}s ({100 * (1 - total / dur):.0f}% removed), {len(merged)} segments')
prev = 0
for s, e in merged:
    if s - prev > 0.05: print(f'  cut {prev:7.2f}-{s:7.2f}  ({s - prev:.2f}s)')
    prev = e
if dur - prev > 0.05: print(f'  cut {prev:7.2f}-{dur:7.2f}  ({dur - prev:.2f}s)')
