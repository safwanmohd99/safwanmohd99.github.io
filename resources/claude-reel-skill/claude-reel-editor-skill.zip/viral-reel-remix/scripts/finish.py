"""Mix voice + SFX + background music (ducked under speech) to Instagram loudness (-14 LUFS), encode the HIGH-QUALITY reel
(up to --max-mb, default 100 MB), make check images.
usage: python3 finish.py <name> [--no-sfx] [--no-music] [--music-db -18] [--max-mb 100] [--share]
  --music-db  music level relative to the voice in LU (default -16; -13 = more present, -20 = barely there)
  --share     also make <name>-share.mp4 (<29 MB, 2-pass) for when a big file can't be delivered (made automatically if HQ > 29.5 MB)
needs ~/edit/base_ov.mp4, voice_cut.wav (+ sfx.wav, music.wav if present)
writes /mnt/user-data/outputs/<name>.mp4 (or ~/edit/out/ if that folder does not exist)"""
import sys, os, re, subprocess
sys.path.insert(0, os.path.dirname(__file__)); from envlib import ff, FF, probe
os.chdir(os.path.expanduser('~/edit')); name = sys.argv[1]; A = sys.argv[2:]
def opt(k, d): return float(A[A.index(k) + 1]) if k in A else d
MUSIC_DB, MAX_MB = opt('--music-db', -16.0), opt('--max-mb', 100.0)
OUT = '/mnt/user-data/outputs' if os.path.isdir('/mnt/user-data') else os.path.expanduser('~/edit/out'); os.makedirs(OUT, exist_ok=True)
def lufs(f):
    e = subprocess.run([FF, '-hide_banner', '-i', f, '-af', 'loudnorm=print_format=summary', '-f', 'null', '-'], capture_output=True).stderr.decode()
    return float(re.search(r'Input Integrated:\s*(-?\d+\.\d+)', e).group(1)), float(re.search(r'Input True Peak:\s*([+-]?\d+\.\d+)', e).group(1))
# ---- audio ----
ff('-i', 'voice_cut.wav', '-af', 'highpass=f=70,acompressor=threshold=-24dB:ratio=2.2:attack=8:release=140:makeup=2', '-ar', '48000', '-c:a', 'pcm_f32le', 'v1.wav')
I, _ = lufs('v1.wav')
ff('-i', 'v1.wav', '-af', f'volume={-14 - I + 0.2:.2f}dB,alimiter=limit=0.82:attack=4:release=60:level=disabled', '-ar', '48000', '-c:a', 'pcm_f32le', 'voice_proc.wav')
use_sfx = '--no-sfx' not in A and os.path.exists('sfx.wav'); use_music = '--no-music' not in A and os.path.exists('music.wav')
ins, chains, mixin, k = ['-i', 'voice_proc.wav'], ['[0:a]asplit=2[v][vk]'], ['[v]'], 1
if use_sfx:
    ins += ['-i', 'sfx.wav']; chains.append(f'[{k}:a]highpass=f=40,volume=4dB[s]'); mixin.append('[s]'); k += 1
if use_music:
    mI, _ = lufs('music.wav'); g = (-14 + MUSIC_DB) - mI; ins += ['-i', 'music.wav']
    # music sits MUSIC_DB under the voice, dips a few dB more while you talk (sidechain), swells back in pauses;
    # a small cut around 2.8 kHz keeps it out of the way of speech clarity
    chains.append(f'[{k}:a]volume={g:.2f}dB,highpass=f=45,equalizer=f=2800:t=q:w=1.2:g=-3[m0];[m0][vk]sidechaincompress=threshold=0.035:ratio=4:attack=25:release=450:knee=4[m]')
    mixin.append('[m]')
else:
    chains.append('[vk]anullsink')
fc = ';'.join(chains) + f";{''.join(mixin)}amix=inputs={len(mixin)}:normalize=0:duration=first[pre]"
ff(*ins, '-filter_complex', fc, '-map', '[pre]', '-ar', '48000', '-c:a', 'pcm_f32le', 'premix.wav')
I2, _ = lufs('premix.wav')
ff('-i', 'premix.wav', '-af', f'volume={-14 - I2:.2f}dB,alimiter=limit=0.84:attack=3:release=50:level=disabled', '-ar', '48000', '-c:a', 'pcm_s16le', 'mix.wav')
print('mix loudness (LUFS, dBTP):', lufs('mix.wav'), '| sfx', use_sfx, '| music', use_music, f'({MUSIC_DB:+.0f} LU vs voice)' if use_music else '')
# ---- video: quality first ----
dur = probe('base_ov.mp4')['dur']; hq = f'{OUT}/{name}.mp4'
TAGS = ['-pix_fmt', 'yuv420p', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709']
AUD = ['-c:a', 'aac', '-b:a', '320k', '-ar', '48000', '-movflags', '+faststart', '-shortest']
base_mb = os.path.getsize('base_ov.mp4') / 1e6
if base_mb + dur * 0.045 <= MAX_MB:      # composite output (CRF 15) already fits: just add the audio, no second generation loss
    ff('-i', 'base_ov.mp4', '-i', 'mix.wav', '-map', '0:v', '-map', '1:a', '-c:v', 'copy', *AUD, hq); how = 'CRF 15 from composite, not re-encoded'
else:
    ff('-i', 'base_ov.mp4', '-i', 'mix.wav', '-map', '0:v', '-map', '1:a', '-c:v', 'libx264', '-preset', 'slow', '-crf', '17', '-profile:v', 'high',
       '-g', '60', '-maxrate', '30M', '-bufsize', '60M', *TAGS, *AUD, hq); how = 'CRF 17 slow'
    if os.path.getsize(hq) / 1e6 > MAX_MB:   # long reel: 2-pass at exactly the size cap
        kb = int((MAX_MB - 2) * 8000 / dur - 330)
        V = ['-c:v', 'libx264', '-preset', 'slow', '-profile:v', 'high', '-b:v', f'{kb}k', '-maxrate', f'{int(kb * 1.5)}k', '-bufsize', f'{kb * 2}k']
        ff('-i', 'base_ov.mp4', *V, '-pass', '1', '-passlogfile', 'p2', '-an', '-f', 'null', '/dev/null')
        ff('-i', 'base_ov.mp4', '-i', 'mix.wav', '-map', '0:v', '-map', '1:a', *V, '-pass', '2', '-passlogfile', 'p2', *TAGS, *AUD, hq)
        how = f'2-pass {kb} kb/s (held to the {MAX_MB:.0f} MB cap)'
mb = os.path.getsize(hq) / 1e6
print(f'HQ reel: {hq}  {mb:.1f} MB  {mb * 8 / dur:.1f} Mb/s  [{how}]')
if '--share' in A or mb > 29.5:
    kb = min(9000, int(27 * 8000 / dur - 200), int(mb * 8000 / dur * 0.85)); sh = f'{OUT}/{name}-share.mp4'
    V = ['-c:v', 'libx264', '-preset', 'slow', '-b:v', f'{kb}k', '-maxrate', f'{int(kb * 1.3)}k', '-bufsize', f'{kb * 2}k']
    ff('-i', hq, *V, '-pass', '1', '-passlogfile', 'p3', '-an', '-f', 'null', '/dev/null')
    ff('-i', hq, *V, '-pass', '2', '-passlogfile', 'p3', *TAGS, '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', sh)
    print(f'share copy (fallback only, if the HQ file cannot be delivered): {sh}  {os.path.getsize(sh) / 1e6:.1f} MB')
ff('-i', hq, '-vf', 'fps=1,scale=216:384,tile=9x5', '-frames:v', '1', 'final_sheet.jpg')
ff('-ss', '0', '-i', hq, '-frames:v', '1', 'first_frame.jpg')
print('check: final_sheet.jpg (1 frame per second) and first_frame.jpg (the cover)')
