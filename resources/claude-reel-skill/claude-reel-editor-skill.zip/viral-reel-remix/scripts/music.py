"""Background music bed -> ~/edit/music.wav (finish.py mixes it low and ducks it under the voice).
usage:
  python3 music.py file <track.mp3|wav> [--start 12.5]   a copyright-free track the user gave (YouTube Audio Library,
                                                       Pixabay Music, Meta Sound Collection, or their own licence)
  python3 music.py gen [calm|upbeat|lofi] [--bpm 92] [--seed 3]
                                                       original bed made in code: no samples, no copyright claim possible
Length = the edit length (edit.json) + 1.5 s tail; 1 s fade in, 2 s fade out. Level is set in finish.py, not here."""
import sys, os, json, subprocess, numpy as np, soundfile as sf
from scipy import signal
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.chdir(os.path.expanduser('~/edit'))
SR = 48000
DUR = json.load(open('edit.json'))['dur'] + 1.5
a = sys.argv[1:]
def opt(k, d): return type(d)(a[a.index(k) + 1]) if k in a else d
def lp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, 'low', fs=SR, output='sos'), x)
def hp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, 'high', fs=SR, output='sos'), x)
def fades(y):
    n = len(y); fi = int(1.0 * SR); fo = int(2.0 * SR)
    y[:fi] *= np.linspace(0, 1, fi)[:, None] ** 2; y[n - fo:] *= np.linspace(1, 0, fo)[:, None] ** 1.5
    return y

if a and a[0] == 'file':
    from envlib import FF
    st = opt('--start', 0.0)
    raw = subprocess.run([FF, '-v', 'error', '-ss', str(st), '-i', a[1], '-f', 'f32le', '-ac', '2', '-ar', str(SR), '-'], capture_output=True).stdout
    y = np.frombuffer(raw, np.float32).reshape(-1, 2).astype(np.float64)
    if len(y) < SR: sys.exit('could not read the track')
    n = int(DUR * SR)
    if len(y) < n:   # loop with a 1.5 s crossfade
        xf = int(1.5 * SR); out = y.copy()
        while len(out) < n:
            r = np.linspace(0, 1, xf)[:, None]; out[-xf:] = out[-xf:] * (1 - r) + y[:xf] * r; out = np.concatenate([out, y[xf:]])
        y = out
    y = fades(y[:n].copy())
else:
    mood = a[1] if len(a) > 1 and not a[1].startswith('--') else 'calm'
    bpm = opt('--bpm', {'calm': 84, 'lofi': 78, 'upbeat': 104}.get(mood, 84)); rng = np.random.default_rng(opt('--seed', 3))
    beat = 60 / bpm; bar = 4 * beat; n = int(DUR * SR); t = np.arange(n) / SR
    # vi-IV-I-V in C (Am F C G), voiced warm and low; midi numbers
    prog = [[57, 60, 64, 69], [53, 57, 60, 65], [48, 55, 60, 64], [55, 59, 62, 67]]
    roots = [45, 41, 48, 43]
    hz = lambda m: 440 * 2 ** ((m - 69) / 12)
    pad = np.zeros(n); bass = np.zeros(n); keys = np.zeros(n); drums = np.zeros(n)
    nb = int(np.ceil(DUR / bar))
    for b in range(nb):
        c = prog[b % 4]; s0 = int(b * bar * SR); L = int(bar * SR); s1 = min(n, s0 + L + int(0.6 * SR)); tt = np.arange(s1 - s0) / SR
        env = np.minimum(1, tt / 0.9) * np.exp(-np.maximum(0, tt - bar) / 0.25)        # slow swell, short release
        for m in c:   # soft detuned saw pad
            for d in (-0.08, 0.08):
                f = hz(m) * 2 ** (d / 12); ph = (f * tt) % 1
                pad[s0:s1] += (2 * ph - 1) * env * 0.06
        f = hz(roots[b % 4]); benv = np.minimum(1, tt / 0.02) * np.exp(-tt / 1.4) * (tt < bar)
        bass[s0:s1] += np.sin(2 * np.pi * f * tt) * benv * 0.5
        # gentle electric-piano arpeggio on 8ths (sine + soft overtone, bell-ish decay)
        for k in range(8):
            if mood == 'calm' and k % 2: continue
            m = c[[0, 2, 1, 3, 2, 1, 3, 2][k]] + 12; ks = s0 + int(k * beat / 2 * SR); ke = min(n, ks + int(1.2 * SR))
            if ks >= n: break
            u = np.arange(ke - ks) / SR; f = hz(m); vel = 0.55 + 0.35 * rng.random()
            keys[ks:ke] += (np.sin(2 * np.pi * f * u) + 0.25 * np.sin(4 * np.pi * f * u) * np.exp(-u / 0.12)) * np.exp(-u / 0.45) * vel * 0.18
        if mood in ('upbeat', 'lofi'):
            for k in range(4):   # kick 1 & 3, snap 2 & 4, hats on 8ths
                ks = s0 + int(k * beat * SR)
                if ks >= n: break
                if k % 2 == 0:
                    m_ = min(n - ks, int(0.35 * SR)); u = np.arange(m_) / SR; fk = 52 * (1 + 1.4 * np.exp(-u / 0.03))
                    drums[ks:ks + m_] += np.sin(2 * np.pi * np.cumsum(fk) / SR) * np.exp(-u / 0.16) * 0.55
                else:
                    m_ = min(n - ks, int(0.18 * SR)); u = np.arange(m_) / SR
                    drums[ks:ks + m_] += hp(rng.standard_normal(m_), 1800) * np.exp(-u / (0.05 if mood == 'upbeat' else 0.09)) * 0.16
                for h in (0, 0.5):
                    hs = ks + int(h * beat * SR); m_ = min(n - hs, int(0.05 * SR))
                    if m_ > 0: u = np.arange(m_) / SR; drums[hs:hs + m_] += hp(rng.standard_normal(m_), 7000) * np.exp(-u / 0.012) * (0.07 if h else 0.05)
    pad = lp(pad, 1400 if mood != 'upbeat' else 2200); keys = lp(keys, 5000); bass = lp(bass, 180)
    if mood == 'lofi':   # warm tape feel: wobble + soft noise floor
        keys = keys * (1 + 0.004 * np.sin(2 * np.pi * 0.6 * t)); pad += lp(rng.standard_normal(n), 3000) * 0.004
    mono = pad + bass + keys + drums
    # stereo: pad/keys slightly wide, bass+drums centre
    wide = pad * 0.6 + keys * 0.5; d = int(0.011 * SR)
    L = mono + np.concatenate([np.zeros(d), wide[:-d]]) * 0.25; R = mono + wide * 0.25
    y = np.stack([L, R], 1)
    # small room so it sits behind the voice
    ir = lp(rng.standard_normal(int(0.6 * SR)) * np.exp(-np.arange(int(0.6 * SR)) / SR / 0.18), 5000); ir /= np.abs(ir).sum()
    y = y * 0.8 + np.stack([signal.fftconvolve(y[:, 0], ir)[:n], signal.fftconvolve(y[:, 1], ir)[:n]], 1) * 2.0
    y = fades(hp(y.T, 35).T)
y = y / (np.max(np.abs(y)) + 1e-9) * 0.7
sf.write('music.wav', y.astype(np.float32), SR, subtype='FLOAT')
print(f'music.wav {len(y) / SR:.1f}s', 'from file' if a and a[0] == 'file' else f'generated ({a[1] if len(a) > 1 else "calm"})')
