---
name: explainer-reel
description: Make faceless informative explainer reels (9:16) from Safwan's voiceover or script, with low-poly 3D worlds, maps, typed keywords, stats and stamps. Use for "explainer reel", "hidden-story style", "informative reel without my face", or when he sends a VO and wants visuals built around it.
---

# Explainer Reel

A faceless, informative reel for Instagram Reels, YouTube Shorts and similar, in the style of Kerala "hidden story" explainers. A low-poly 3D world with a camera that never stops moving. A big colour-coded keyword types on at the top. A caption box with gold accent words sits in the lower middle. Stats count up, stamps slam in, map pins drop. It ends with a comment CTA and **saf.wan_here + Follow**.

Safwan only supplies the **information**: a voiceover (VO), a script, or both. Claude builds everything visual. This is not the talking-head reel skill. Use reel-edit-styles when his face is on camera.

## What's bundled
- `templates/explainer.html`: the whole engine. It has a Three.js low-poly world (terrain, water, props, moods, camera moves), the graphics toolkit as a DOM layer, and `seek(t)`, so every frame is a pure function of time.
- `templates/story.example.js`: a working 16-second example of every common element. Copy its shape.
- `scripts/setup.sh <dir>`: makes a work folder and installs three.js and fonts (Baloo Chettan 2 for keywords, Poppins for captions; both cover Latin and Malayalam).
- `scripts/render.mjs <dir> [--vo f] [--fps 30] [--out reel.mp4] [--stills 1,4.5,9] [--from a --to b]`: headless Chromium renders the frames, then ffmpeg encodes them and mixes in the VO plus quiet synthesised sound effects. `--stills` only writes test frames and `sheet.jpg`.
- `scripts/align.py vo.mp3 script.txt`: rough caption timings from silence gaps when no transcript timings exist.
- `scripts/sfx.py`: synthesised whoosh, pop, thump, tick, riser and ding. No samples, no music.

If `templates/` or `scripts/` are missing (the skill was saved from the text only), tell Safwan the skill files are missing and ask him to re-add the explainer-reel zip. Don't improvise a different pipeline silently.

## Workflow

### 0. Before building
Safwan's standing rule: discuss the approach and get his confirmation **twice** before a heavy build, because it saves his credits. For this skill:
1. **First check:** share the beat sheet (step 3).
2. **Second check:** share the test stills (step 6).

Only then render the full video.

### 1. Inputs
- **VO audio** (mp3/m4a/wav). Copy it to `<work>/vo.mp3` (convert with ffmpeg if needed).
- **Script** (optional but best): one caption line per line, in his exact words.
- **Language:** follow whatever he uses that time (Manglish in Latin letters, English, or a mix). Never convert to Malayalam script unless he asks. Keep English terms English.
- **Real photos or clips** he wants in, if any. Save them to `<work>/assets/`.

### 2. Timings
Best to worst:
1. Word timings from Descript (export SRT through the Descript connector if available) or from Whisper, if it installs and its model downloads.
2. `align.py` with his script lines. Then listen through the VO's silence gaps and nudge times by hand.
3. Script only, with no VO yet: time it at about 2.6 words per second, and say timings will be redone when the VO arrives.

Captions: 1–5 words, max two lines, lowercase Manglish as spoken. Put `*` around 1–2 accent words per caption (numbers, names, the key noun).

### 3. Beat sheet (first confirmation)
Map the VO onto the story arc. Don't rewrite his script; only flag a missing hook or CTA:

`HOOK question (0–3 s) → setup/where → the conflict/twist → stakes (numbers) → who/what changed it → result → "still there today" → CTA`

Then write a table, one row per scene, with these columns:

| time | VO line | world + mood | camera move | top keyword (colour) | extra graphics |

Rules that make this style work:
- **New 3D scene every 4–5 s.** The camera always moves (push-in, orbit, fly-over, crane down). Never use a static shot.
- **New graphic or keyword every 2–3 s.** Something changes on screen constantly.
- **Keyword colours carry meaning:**
  - 🔴 `red`: conflict, danger, question, "no" (DAM, aaru?, venda, kadal)
  - 🟡 `gold`: key idea, number, year, the answer (PLAN, 1964, chihnam)
  - 🔵 `cyan`: names and places (Mannarkkad, Indira Gandhi)
  - ⚪ `white`: neutral beats
  - 🟢 `green`: good outcome
- **The keyword is the single most important word** of that moment. Use 1–2 words, often ending in `?` for questions. Don't repeat the caption.
- **Frame 1 is a hook card:** a two-line question ("World War...", "Nilambur-il?"). It names the mystery immediately.
- **Show, don't decorate.** Each visual illustrates the literal claim: "8 km² underwater" means water rises over the land; "stopped" means a red stamp; "who?" means a ❓ icon.
- **End:** a "comment" bubble, then **saf.wan_here** with a **Follow** pill. Optionally first a share line ("ariyatha oralkku send cheyyu") or a "next story?" teaser. Loop back to the opening world so the reel replays smoothly.
- **Sources:** use a source chip (`• Kerala Tourism parayunnath`) only for sources Safwan named. Never invent facts, numbers, dates or sources. If a claim in the VO looks wrong, flag it to him and don't "fix" it on screen.

Send him the beat sheet and wait for his OK.

### 4. Set up and write story.js
```bash
bash <skill>/scripts/setup.sh ~/explainer      # creates explainer.html, story.js, node_modules
```
Then edit `~/explainer/story.js` (same shape as the example). Every element has `t` (start, seconds on the VO) and `d` (duration).

**scenes**: `{ t, d, mood, world, cam, props, build?, update? }`
- `mood`: `day | warm | dusk | night | storm`
  - `warm` suits history, myth and indoor scenes; `night` and `storm` suit danger.
- `world.type`: `terrain` (hills), `coast` (low land + sea) or `flat`.
  - `flat` takes `ground: field | forest | sand | dirt | table | snow | 0xhex`.
- Terrain options:
  - `seed`, `amp` (height), `scale`, `water` (sea level)
  - `waterTo: [tStart, tEnd, fromY, toY]` for floods and tides
  - `carve: [[x, z, radius, depth]]` for valleys, lakes and riverbeds
  - `raise: [[x, z, radius, height]]` for a hill or mountain
  - `palette`
- `cam`: `from`/`to` positions, `look`/`lookTo` targets, `fov`/`fovTo`. The template eases between them over the scene.
- `props`: `{ type, pos:[x,z], count, area:[w,d], scale, rot, y, appear: t, stagger }`
  - Types: `tree, tallTree, palm, house, hut, rock, tower, boat, box, person`.
  - `count` scatters props over `area`. `appear` pops them in at that time.
- `build(THREE, group, {P, M, heightAt})`: write bespoke low-poly objects for this story, like a dam, train, temple, bridge, pot, book or ship. Keep them to simple boxes, cylinders and cones with flat colours. `M(color)` gives the house material.
- `update(THREE, group, localT, t)`: per-frame animation, such as a train moving, smoke rising or a dam disappearing. It must depend only on time.

**hook**: `[{ t, d, lines: ['line 1', 'line 2'] }]`

**keywords**: `[{ t, d, text, color, speed? }]`. Typing is grapheme-safe (Malayalam works too).

**captions**: `[{ t, d, text }]`, with `*accent*` for gold words.

**gfx**: graphics with `type`:

| type | fields | use for |
|---|---|---|
| `pin` | `label, world:[x,y,z]` or `screen:[x%,y%]`, `stem` | places on the map |
| `chip` | `text` | a source tag under the keyword |
| `name` | `name, role` | a person introduced |
| `counter` | `from, to, unit, color, plus, decimals, dur` | big stats (8 km², 1,000+) |
| `gauge` | `from, to, max, unit, dur` | heights and levels rising (23 ft) |
| `stamp` | `text, color: red/green, mark: x/check, rot` | verdicts (NIRTHI, GHOST TOWN, mulachu ✓) |
| `banner` | `text, rot` | a movement or slogan (SAVE SILENT VALLEY) |
| `icon` | `name: question/cross/check/bulb/clock/search, x, y, size, minutes, hours, spin` | quick visual jokes and cues |
| `route` | `stops:[...], progress:[a,b], dur` | journeys (Madras → Dhanushkodi → Sri Lanka) |
| `compare` | `big, small` | scale surprises (1,500 acres? vs 2 acres?) |
| `photo` | `src: 'assets/x.jpg', caption, rot` | one real archive photo he supplies |
| `recap` | `items:[{k, v}], step` | the end summary stack |
| `flash` | (time only) | a red danger vignette pulse |

**end**: `{ t, d, handle: 'saf.wan_here', comment: 'comment' }`

**Layout rules:**
- One top element at a time: the keyword, name card, counter, gauge or stamp. Don't overlap them; give each its own seconds.
- Captions sit about 25% from the bottom, clear of the Instagram UI.
- Keep anything important out of the bottom 380 px and the right 140 px (IG buttons).

**Other options:** `duration` (defaults to the VO length), `glScale` (3D render resolution, default 0.6: lower is faster, the text stays sharp), `progressBar` (off by default; he doesn't want a series label).

### 5. Visuals the template can't model
If a beat needs something realistic (an animal, a face, a crowd, a detailed machine), offer two routes:
- **(a)** A stylised low-poly stand-in built with `build()`.
- **(b)** A ready-to-paste prompt for an AI video tool (Kling, Veo, Runway). He generates the clip and Claude drops it in, as a `photo` card or as a full-frame background segment, overlaid in ffmpeg on the rendered reel.

Prompt format: `9:16 vertical, stylised low-poly 3D render, soft daylight, slow cinematic camera push-in, [subject + action], muted natural palette, no text, 5 seconds`.

Never draw copyrighted characters, real people's likenesses, or other creators' branding (no "Hidden Stories" or "Suvith Talks" marks).

### 6. Test stills (second confirmation)
```bash
cd ~/explainer && node <skill>/scripts/render.mjs ~/explainer --stills 0.5,3,6,9,...   # one per scene + the end
```
Look at `sheet.jpg` yourself first, and check that:
- text is readable and nothing is cut off
- keywords don't collide
- the world is visible (not too dark, not covered by water or hills: use `carve` or a higher camera)
- every number and claim on screen matches the VO

Fix, re-check, then send Safwan the sheet and wait for his OK.

### 7. Render
```bash
node <skill>/scripts/render.mjs ~/explainer --out reel.mp4      # uses ~/explainer/vo.mp3
```
- About 0.5 s per frame on CPU, so a 60 s reel at 30 fps takes ~15 minutes. Run it in the background. Use `--fps 24` for faster renders.
- The output is 1080×1920 H.264 with the VO loudness-normalised and sound effects at about 30%.
- Effects are automatic: whoosh on scene changes, pop on keywords and graphics, thump on stamps, tick on counters, riser on gauges and flashes, ding on the end card.
- No music. If he wants music, he adds it on Instagram.

### 8. Deliver
- Send `reel.mp4` with one line on what's in it.
- Offer an Instagram caption and 3–5 hashtags if he wants them.
- Keep `story.js`, so changes are quick edits plus a re-render. Use `--from/--to` to preview one section.

## Troubleshooting
- **A blank or black 3D layer:** check the browser console errors that render.mjs prints. Usually a typo in `story.js`, a missing `node_modules`, or a bad `build()` function.
- **Scene too dark:** use mood `dusk` instead of `night`, or add a light in `build()`.
- **Water covers everything:** lower the `waterTo` end level, or `carve` a basin and keep the water inside it.
- **Slow renders:** lower `glScale` to 0.5, use `--fps 24`, or cut `count` on scattered props.
