"""Rough caption timing from a voiceover + Safwan's script, when no word timestamps exist.
usage: python3 align.py vo.mp3 script.txt > captions.json
script.txt: one caption per line (1-5 words, Manglish/English as he speaks), *accent* words allowed.
Speech regions come from ffmpeg silencedetect; lines are spread over the speech time in
proportion to their length. Always check the result against the audio and nudge by hand.
Better source when available: an SRT/word timings from Descript or Whisper.
"""
import json, re, subprocess, sys

def speech_regions(vo, noise='-35dB', min_sil=0.25):
    dur = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', vo]))
    log = subprocess.run(['ffmpeg', '-i', vo, '-af', f'silencedetect=n={noise}:d={min_sil}', '-f', 'null', '-'],
                         capture_output=True, text=True).stderr
    starts = [float(x) for x in re.findall(r'silence_start: ([\d.]+)', log)]
    ends = [float(x) for x in re.findall(r'silence_end: ([\d.]+)', log)]
    regions, cur = [], 0.0
    for s, e in zip(starts, ends + [dur] * (len(starts) - len(ends))):
        if s - cur > 0.05: regions.append([cur, s])
        cur = e
    if dur - cur > 0.05: regions.append([cur, dur])
    return regions, dur

def main():
    vo, script = sys.argv[1], sys.argv[2]
    lines = [l.strip() for l in open(script, encoding='utf-8') if l.strip()]
    regions, dur = speech_regions(vo)
    total = sum(e - s for s, e in regions)
    weights = [max(3, len(l.replace('*', ''))) for l in lines]
    W = sum(weights)
    # walk along speech time
    caps, ri, pos = [], 0, regions[0][0] if regions else 0
    for l, w in zip(lines, weights):
        need = total * w / W; t0 = pos
        while need > 1e-6 and ri < len(regions):
            room = regions[ri][1] - pos
            if need <= room: pos += need; need = 0
            else:
                need -= room; ri += 1
                if ri < len(regions): pos = regions[ri][0]
        caps.append({'t': round(t0, 2), 'd': round(max(0.4, pos - t0), 2), 'text': l})
    json.dump({'duration': round(dur, 2), 'captions': caps}, sys.stdout, ensure_ascii=False, indent=1)

if __name__ == '__main__':
    main()
