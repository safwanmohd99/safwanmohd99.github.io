// Render an explainer reel: node render.mjs <workdir> [--vo vo.mp3] [--fps 30] [--out reel.mp4]
//                                          [--stills 0.5,3,7.2]  (test frames + contact sheet only)
//                                          [--from 0 --to 10]    (render a slice)
import { createRequire } from 'node:module';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
// resolve playwright from the work folder / global install (ESM can't use NODE_PATH)
const { chromium } = createRequire(path.join(process.cwd(), 'noop.js'))('playwright');
const args = process.argv.slice(2);
const dir = path.resolve(args[0] || '.');
const opt = (k, d) => { const i = args.indexOf('--' + k); return i > 0 ? args[i + 1] : d; };
const fps = +opt('fps', 30);
const vo = opt('vo', fs.existsSync(path.join(dir, 'vo.mp3')) ? path.join(dir, 'vo.mp3') : (fs.existsSync(path.join(dir, 'vo.wav')) ? path.join(dir, 'vo.wav') : null));
const out = path.resolve(dir, opt('out', 'reel.mp4'));
const stills = opt('stills', null);

// static server (ES modules don't load from file://)
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp' };
const server = http.createServer((q, r) => {
  const p = path.join(dir, decodeURIComponent(q.url.split('?')[0]));
  if (!p.startsWith(dir) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { r.writeHead(404); return r.end(); }
  r.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream' }); fs.createReadStream(p).pipe(r);
}).listen(0);
const port = server.address().port;

const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
page.on('pageerror', e => console.error('PAGE ERROR:', e.message));
page.on('console', m => { if (m.type() === 'error') console.error('console:', m.text()); });
await page.goto(`http://127.0.0.1:${port}/explainer.html`);
await page.waitForFunction('window.READY === true', null, { timeout: 120000 });

const voDur = vo ? +execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', vo]).toString() : 0;
const storyDur = await page.evaluate('window.STORY.duration');
const dur = +opt('to', voDur || storyDur) - +opt('from', 0);
const t0 = +opt('from', 0);

if (stills) {
  const sd = path.join(dir, 'stills'); fs.mkdirSync(sd, { recursive: true });
  const ts = stills.split(',').map(Number); const files = [];
  for (const t of ts) { await page.evaluate(t => window.seek(t), t); const f = path.join(sd, `t${t.toFixed(2)}.jpg`);
    await page.screenshot({ path: f, type: 'jpeg', quality: 85 }); files.push(f); }
  const cols = Math.min(files.length, 6), rows = Math.ceil(files.length / cols);
  execFileSync('ffmpeg', ['-v', 'error', '-y', ...files.flatMap(f => ['-i', f]), '-filter_complex',
    files.map((_, i) => `[${i}]scale=360:-1,drawtext=text='${ts[i]}s':x=8:y=8:fontsize=28:fontcolor=yellow:box=1:boxcolor=black[s${i}]`).join(';') + ';' +
    (files.length > 1 ? files.map((_, i) => `[s${i}]`).join('') + `xstack=inputs=${files.length}:layout=` + files.map((_, i) => `${(i % cols) * 360}_${Math.floor(i / cols) * 640}`).join('|') + `:fill=black` : '[s0]null'),
    path.join(dir, 'sheet.jpg')]);
  console.log('stills ->', sd, ' contact sheet ->', path.join(dir, 'sheet.jpg'));
  await browser.close(); server.close(); process.exit(0);
}

// frames -> ffmpeg (video only)
const silent = path.join(dir, '_video.mp4');
const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-',
  '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p', silent], { stdio: ['pipe', 'inherit', 'inherit'] });
const N = Math.ceil(dur * fps); const start = Date.now();
for (let i = 0; i < N; i++) {
  const t = t0 + i / fps;
  await page.evaluate(t => window.seek(t), t);
  const buf = await page.screenshot({ type: 'jpeg', quality: 92 });
  if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
  if (i % (fps * 5) === 0) console.log(`frame ${i}/${N}  (${((Date.now() - start) / 1000).toFixed(0)}s)`);
}
ff.stdin.end(); await new Promise(r => ff.on('close', r));

// sound effects
const sfx = (await page.evaluate('window.getSfx()')).map(e => ({ ...e, t: e.t - t0 })).filter(e => e.t >= 0 && e.t < dur);
await browser.close(); server.close();
fs.writeFileSync(path.join(dir, 'sfx_events.json'), JSON.stringify(sfx, null, 1));
const sfxWav = path.join(dir, '_sfx.wav');
execFileSync('python3', [path.join(HERE, 'sfx.py'), path.join(dir, 'sfx_events.json'), String(dur), sfxWav], { stdio: 'inherit' });

// mux: VO + quiet SFX (no music)
const a = ['-v', 'error', '-y', '-i', silent];
if (vo) a.push('-ss', String(t0), '-t', String(dur), '-i', vo);
a.push('-i', sfxWav);
const fc = vo ? '[1:a]loudnorm=I=-16:TP=-1.5[v];[2:a]volume=0.30[s];[v][s]amix=inputs=2:normalize=0:duration=first[a]' : '[1:a]volume=0.30[a]';
a.push('-filter_complex', fc, '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-t', String(dur), '-movflags', '+faststart', out);
execFileSync('ffmpeg', a, { stdio: 'inherit' });
fs.unlinkSync(silent);
console.log('done ->', out);
