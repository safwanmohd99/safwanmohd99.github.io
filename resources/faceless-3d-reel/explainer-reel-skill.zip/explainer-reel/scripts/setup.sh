#!/usr/bin/env bash
# Create a work folder for one explainer reel: bash setup.sh ~/explainer
set -e
SKILL="$(cd "$(dirname "$0")/.." && pwd)"
W="${1:-$HOME/explainer}"
mkdir -p "$W/assets"
cp --update=none "$SKILL/templates/explainer.html" "$W/explainer.html"
[ -f "$W/story.js" ] || cp "$SKILL/templates/story.example.js" "$W/story.js"
cd "$W"
[ -f package.json ] || npm init -y >/dev/null
npm i --silent three@0.160.0 @fontsource/baloo-chettan-2@5.0.8 @fontsource/poppins@5.0.8
node -e "require('playwright')" 2>/dev/null || npm i --silent playwright
echo "ready: $W  (edit story.js, put the voiceover at $W/vo.mp3)"
