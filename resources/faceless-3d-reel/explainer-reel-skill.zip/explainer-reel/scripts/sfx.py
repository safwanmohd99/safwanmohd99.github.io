"""Synthesise a quiet sound-effect track from cue events (no samples needed).
usage: python3 sfx.py events.json duration_seconds out.wav
kinds: whoosh, pop, thump, tick, riser, ding
"""
import json, sys, wave
import numpy as np

SR = 48000
rng = np.random.default_rng(7)

def env(n, a=0.005, r=None):
    t = np.arange(n) / SR
    e = np.minimum(1, t / max(a, 1e-4))
    if r: e *= np.exp(-t / r)
    return e

def whoosh():
    n = int(.45 * SR); x = rng.standard_normal(n)
    # sweep a simple one-pole low-pass from dark to bright and back
    cut = np.sin(np.linspace(0, np.pi, n)) ** 2 * .35 + .02
    y = np.zeros(n); s = 0.0
    for i in range(n): s += cut[i] * (x[i] - s); y[i] = s
    return y * np.sin(np.linspace(0, np.pi, n)) * 1.6

def pop():
    n = int(.09 * SR); t = np.arange(n) / SR
    f = 900 * np.exp(-t * 30) + 380
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, .002, .025) * .8

def thump():
    n = int(.35 * SR); t = np.arange(n) / SR
    f = 140 * np.exp(-t * 9) + 45
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, .002, .09)
    click = rng.standard_normal(n) * env(n, .001, .008) * .5
    return (body + click) * 1.1

def tick():
    out = np.zeros(int(1.0 * SR))
    for k in range(8):
        n = int(.02 * SR); s = int(k * .12 * SR)
        out[s:s + n] += np.sin(2 * np.pi * 2200 * np.arange(n) / SR) * env(n, .001, .004) * .5
    return out

def riser():
    n = int(.9 * SR); t = np.arange(n) / SR
    f = 200 + 900 * (t / t[-1]) ** 2
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * (t / t[-1]) * .35

def ding():
    n = int(1.2 * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * 1318 * t) + .5 * np.sin(2 * np.pi * 1976 * t)) * env(n, .003, .35) * .45

KIND = dict(whoosh=whoosh, pop=pop, thump=thump, tick=tick, riser=riser, ding=ding)

def main():
    ev = json.load(open(sys.argv[1])); dur = float(sys.argv[2]); out = sys.argv[3]
    track = np.zeros(int(dur * SR) + SR)
    last = {}
    for e in ev:
        k = e['k']; t = float(e['t'])
        if k not in KIND or t - last.get(k, -9) < .18: continue   # avoid machine-gun repeats
        last[k] = t; s = KIND[k](); i = int(t * SR)
        track[i:i + len(s)] += s[:len(track) - i]
    track = track[:int(dur * SR)]
    track /= max(1e-6, np.abs(track).max()); track *= .7
    pcm = (track * 32767).astype(np.int16)
    with wave.open(out, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())

if __name__ == '__main__':
    main()
