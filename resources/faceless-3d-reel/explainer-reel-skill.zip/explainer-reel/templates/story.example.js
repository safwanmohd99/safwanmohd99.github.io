// story.js: one reel = one STORY. Times are seconds on the voiceover.
// Every element: t = start, d = how long it stays. Captions: 1-5 words, *accent* words turn gold.
// Keyword colours: red = conflict/question/danger, gold = key idea/number/year,
//                  cyan = name/place, white = neutral, green = good outcome.
window.STORY = {
  duration: 16,
  progressBar: false,

  // ---- 3D scenes: a new one every ~4-5 s, camera always moving ----
  scenes: [
    { t: 0, d: 5, mood: 'day',
      world: { type: 'terrain', seed: 11, amp: 26, water: 0 },
      cam: { from: [0, 150, 170], to: [10, 70, 90], look: [0, 0, 0], lookTo: [8, 0, 0] },
      props: [{ type: 'tree', count: 60, area: [120, 120], scale: 1.2 }] },

    { t: 5, d: 5.5, mood: 'dusk',
      world: { type: 'terrain', seed: 3, amp: 8, water: -3, waterTo: [6.5, 9.5, -3, 0.5], carve: [[0, -5, 28, 14]] },   // water rises 6.5s→9.5s
      cam: { from: [-30, 75, 85], to: [-10, 60, 65], look: [0, 0, -10] },
      props: [{ type: 'house', count: 8, area: [30, 20], pos: [0, -5], appear: 5.4, stagger: .1 }, { type: 'palm', count: 14, area: [60, 50] }],
      // bespoke prop: a simple dam wall (write these per reel when a story needs a specific object)
      build(THREE, g, { M }) { const d = new THREE.Mesh(new THREE.BoxGeometry(30, 10, 3), M(0xd7dde3)); d.position.set(0, 2, -32); g.add(d); } },

    { t: 10.5, d: 5.5, mood: 'night',
      world: { type: 'flat', ground: 'forest' },
      cam: { from: [0, 6, 26], to: [0, 5, 16], look: [0, 4, 0] },
      props: [{ type: 'tallTree', count: 40, area: [70, 50], pos: [0, -20] }, { type: 'person', pos: [0, 0], scale: 2 }] },
  ],

  hook: [{ t: 0, d: 2.4, lines: ['Oru dam...', 'Mannarkkad-il?'] }],

  keywords: [
    { t: 2.6, d: 2.2, text: 'PLAN', color: 'gold' },
    { t: 5.2, d: 1.5, text: 'DAM', color: 'red' },
  ],

  captions: [
    { t: 0.2, d: 2.3, text: 'Oru *dam* varan pokuvayirunnu' },
    { t: 2.6, d: 2.3, text: '*1970*-il oru plan' },
    { t: 5.1, d: 1.6, text: 'Dam vannal?' },
    { t: 6.7, d: 2.4, text: '*8 square km* vellathinadiyil' },
    { t: 9.2, d: 1.2, text: '*Nirthi.*' },
    { t: 10.6, d: 2.8, text: 'Oraal karanam' },
  ],

  gfx: [
    { type: 'pin', t: 0.4, d: 4.3, label: 'Mannarkkad', world: [8, 12, 0], stem: 110 },
    { type: 'chip', t: 3.2, d: 1.6, text: 'Electricity Board plan' },
    { type: 'counter', t: 6.7, d: 2.4, from: 0, to: 8, unit: 'km²', color: 'red' },
    { type: 'flash', t: 6.7, d: 1.2 },
    { type: 'stamp', t: 9.2, d: 1.3, text: 'NIRTHI', mark: 'x', color: 'red' },
    { type: 'name', t: 11.2, d: 2.2, name: 'Ramettan', role: 'local teacher' },
    { type: 'recap', t: 13.4, d: 1.8, step: .45, items: [{ k: 'Plan', v: 'Dam' }, { k: 'Result', v: 'Nirthi' }] },
  ],

  end: { t: 14.2, d: 2, handle: 'saf.wan_here', comment: 'comment' },
};
